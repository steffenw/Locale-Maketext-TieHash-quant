package MyProgram::L10N;

use strict;
use warnings;

our $VERSION = 0;

use parent qw(Locale::Maketext);

1;

__END__

$Id$
